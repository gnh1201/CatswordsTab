﻿using RestSharp;
using RestSharp.Serialization.Json;
using System.Collections.Generic;
using System.Windows.Controls;

namespace CatswordsTab.WpfApp.Page
{
    /// <summary>
    /// Interaction logic for ReputationPage.xaml
    /// </summary>
    public partial class ReputationsPage : UserControl
    {
        public class DataItem
        {
            public string CreatedOn { get; set; }
            public string Message { get; set; }
            public string HashMD5 { get; set; }
            public string HashSHA1 { get; set; }
        }

        private class DataModel
        {
            public bool Success { get; set; }
            public List<DataItem> Data { get; set; }
        }

        public ReputationsPage()
        {
            InitializeComponent();

            var client = new RestClient("https://catswords.re.kr/ep/?route=api.tab.json");
            var request = new RestRequest(Method.GET);
            var response = client.Execute(request);
            JsonDeserializer deserial = new JsonDeserializer();
            DataModel dataModel = deserial.Deserialize<DataModel>(response);
            List<DataItem> items = dataModel.Data;
            dg1.ItemsSource = items;
        }
    }
}
