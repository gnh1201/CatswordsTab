﻿namespace CatswordsTab.WpfApp.Model
{
    public class FontModel
    {
        public string Name { get; set; }
        public string FamilyName { get; set; }
        public string InstallDate { get; set; }
        public string Organization { get; set; }
    }
}
