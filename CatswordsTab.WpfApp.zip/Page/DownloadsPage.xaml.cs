﻿using CatswordsTab.WpfApp.Service;
using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Controls;

namespace CatswordsTab.WpfApp.Page
{
    /// <summary>
    /// Interaction logic for DownloadsPage.xaml
    /// </summary>
    public partial class DownloadsPage : UserControl
    {
        public class DataModel
        {
            public DateTime CreationTime { get; set; }
            public string FileName { get; set; }
            public string FileType { get; set; }
        }

        public DownloadsPage()
        {
            InitializeComponent();

            // https://stackoverflow.com/a/14877330
            List<DataModel> items = new List<DataModel>();
            string downloadsPath = KnownFolderService.GetPath(KnownFolder.Downloads);
            DirectoryInfo d = new DirectoryInfo(downloadsPath); // Assuming Test is your Folder
            FileInfo[] Files = d.GetFiles(); // Getting Text files
            foreach (FileInfo file in Files)
            {
                items.Add(new DataModel
                {
                    CreationTime = file.CreationTime,
                    FileName = file.Name,
                    FileType = MIMETypeService.GetContentType(file.FullName)
                });
            }
            dg1.ItemsSource = items;
        }
    }
}
