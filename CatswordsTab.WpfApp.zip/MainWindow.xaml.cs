﻿using CatswordsTab.WpfApp.Service;
using System.Windows;
using System.Windows.Controls;

namespace CatswordsTab.WpfApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void NewTap(object Content, string Header = "Untitled", string Name = null)
        {
            TabItem tcItem = new TabItem
            {
                Header = Header,
                Name = Name,
                Content = Content
            };
            tcMain.Items.Add(tcItem);
            tcItem.Focus();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // todo
        }

        private void Button_Applications_Clicked(object sender, RoutedEventArgs e)
        {
            NewTap(new CatswordsTab.WpfApp.Page.ApplicationsPage(), "Applications");
        }

        private void Button_Associations_Clicked(object sender, RoutedEventArgs e)
        {
            NewTap(new CatswordsTab.WpfApp.Page.AssociationsPage(), "Associations");
        }

        private void Button_Downloads_Clicked(object sender, RoutedEventArgs e)
        {
            NewTap(new CatswordsTab.WpfApp.Page.DownloadsPage(), "Downloads");
        }

        private void Button_Activity_Clicked(object sender, RoutedEventArgs e)
        {
            NewTap(new CatswordsTab.WpfApp.Page.SigninPage(), "Sign in");
        }

        private void Button_Talk_Clicked(object sender, RoutedEventArgs e)
        {
            NewTap(new CatswordsTab.WpfApp.Page.SigninPage(), "Sign in");
        }

        private void Button_Papers_Clicked(object sender, RoutedEventArgs e)
        {
            NewTap(new CatswordsTab.WpfApp.Page.SigninPage(), "Sign in");
        }

        private void Button_Info_Clicked(object sender, RoutedEventArgs e)
        {
            NewTap(new CatswordsTab.WpfApp.Page.SigninPage(), "Sign in");
        }

        private void Button_Reputations_Clicked(object sender, RoutedEventArgs e)
        {
            NewTap(new CatswordsTab.WpfApp.Page.ReputationsPage(), "Reputations");
        }

        private void Button_Browse_Clicked(object sender, RoutedEventArgs e)
        {
            string filename = FileService.ChooseFile();
        }

        private void Button_Fonts_Clicked(object sender, RoutedEventArgs e)
        {
            NewTap(new CatswordsTab.WpfApp.Page.FontsPage(), "FontFamily");
        }

        private void Button_Kakao_Clicked(object sender, RoutedEventArgs e)
        {
            NewTap(new CatswordsTab.WpfApp.Page.SocialPage("https://discord.gg/359930650330923008"), "Kakao");
        }

        private void Button_Discord_Clicked(object sender, RoutedEventArgs e)
        {
            NewTap(new CatswordsTab.WpfApp.Page.SocialPage("https://pf.kakao.com/_mNxisj"), "Kakao");
        }

        private void Button_Web_Clicked(object sender, RoutedEventArgs e)
        {
            NewTap(new CatswordsTab.WpfApp.Page.SocialPage("https://exts.kr"), "Web");
        }

        private void Button_Decryptor_Clicked(object sender, RoutedEventArgs e)
        {
            NewTap(new CatswordsTab.WpfApp.Page.DecryptorPage(), "Decryptor");
        }
    }
}
