﻿using System.Windows.Forms;

namespace CatswordsTab.WpfApp.Service
{
    public static class FileService
    {
        public static string ChooseFile()
        {
            string filename = null;

            System.Windows.Forms.OpenFileDialog fd = new System.Windows.Forms.OpenFileDialog();
            fd.Title = "Choose your file...";
            if (fd.ShowDialog() == DialogResult.OK)
            {
                filename = fd.FileName;
            }

            return filename;
        }
    }
}
