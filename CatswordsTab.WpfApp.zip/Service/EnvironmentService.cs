﻿using CatswordsTab.WpfApp.Model;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Text;

namespace CatswordsTab.WpfApp.Service
{
    public static class EnvironmentService
    {
        public static List<FontModel> GetInstalledFonts()
        {
            List<FontModel> fonts = new List<FontModel>();

            using (InstalledFontCollection col = new InstalledFontCollection())
            {
                foreach (FontFamily fa in col.Families)
                {
                    fonts.Add(new FontModel
                    {
                        Name = fa.Name,
                        FamilyName = fa.Name,
                        InstallDate = "unknown",
                        Organization = "unknown"
                    });
                }
            }

            return fonts;
        }
    }
}
