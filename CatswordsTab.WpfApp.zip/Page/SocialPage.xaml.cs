﻿using System.Windows.Controls;
using CefSharp.Wpf;

namespace CatswordsTab.WpfApp.Page
{
    /// <summary>
    /// Interaction logic for SocialPage.xaml
    /// </summary>
    public partial class SocialPage : UserControl
    {
        private ChromiumWebBrowser browser;

        public SocialPage(string URI)
        {
            InitializeComponent();

            browser = new ChromiumWebBrowser()
            {
                Address = URI
            };
            wb1.Content = browser;
        }
    }
}
