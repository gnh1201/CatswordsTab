﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CatswordsTab.WpfApp.Model
{
    public class LocalizationModel
    {
        public string MsgId { get; set; }
        public string MsgStr { get; set; }
    }
}
